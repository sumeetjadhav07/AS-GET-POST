from flask import Flask, request, render_template, redirect, url_for

app = Flask(__name__)


products = {
    1: {"name": "Laptop", "price": 1000},
    2: {"name": "Smartphone", "price": 500},
    3: {"name": "Tablet", "price": 300},
}


@app.route('/')
def home():
    return render_template('index.html', products=products)


@app.route('/product/<int:product_id>', methods=['GET'])
def product_detail(product_id):
    product = products.get(product_id)
    if product:
        return render_template('product_detail.html', product=product)
    return "Product not found", 404


@app.route('/order', methods=['POST'])
def order():
    product_id = request.form.get('product_id')
    quantity = request.form.get('quantity')
    if product_id and quantity:
        product = products.get(int(product_id))
        if product:
            total_price = int(quantity) * product['price']
            return f"Order placed for {quantity} x {product['name']}. Total: ${total_price}"
    return "Invalid order", 400

if __name__ == '__main__':
    app.run(debug=True)
